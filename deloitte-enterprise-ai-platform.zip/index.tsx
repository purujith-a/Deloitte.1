
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { dbService } from './services/databaseService';
import { geminiService } from './services/geminiService';

const Icons = {
  Deloitte: () => <div className="w-5 h-5 bg-[#86BC25] rounded-full shadow-[0_0_15px_rgba(134,188,37,0.6)] animate-pulse"></div>,
  Directory: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 15.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
  AI: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>,
  Dashboard: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Close: () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>,
  Code: () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>,
  Add: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
};

const CHART_COLORS = [
  'linear-gradient(180deg, #86BC25 0%, #4D7411 100%)', // Deloitte Green
  'linear-gradient(180deg, #00A1DE 0%, #00506F 100%)', // Bright Blue
  'linear-gradient(180deg, #FFCD00 0%, #A38400 100%)', // Gold
  'linear-gradient(180deg, #ED8B00 0%, #915400 100%)', // Orange
  'linear-gradient(180deg, #E31C79 0%, #8E114C 100%)', // Magenta
  'linear-gradient(180deg, #6C207E 0%, #3B1145 100%)', // Purple
  'linear-gradient(180deg, #002147 0%, #000B18 100%)', // Navy
  'linear-gradient(180deg, #404041 0%, #1A1A1A 100%)'  // Slate
];

const EnrollmentForm = ({ onCancel, onSuccess }: { onCancel: () => void, onSuccess: (name: string) => void }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    salary: '',
    regionId: '1',
    deptId: '1',
    roleId: '1'
  });
  const [error, setError] = useState('');

  const validate = () => {
    if (!formData.firstName || !formData.lastName) return "First and Last name are mandatory.";
    if (!formData.email.toLowerCase().endsWith('@deloitte.com')) return "Security Protocol Violation: Email must be a valid @deloitte.com domain.";
    const sal = parseInt(formData.salary);
    if (isNaN(sal) || sal < 30000 || sal > 1000000) return "Financial Constraint: Salary must be between $30,000 and $1,000,000.";
    return null;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      dbService.query(`
        INSERT INTO employees (first_name, last_name, deloitte_email, current_salary, region_id, department_id, role_id, joining_date, biography)
        VALUES ('${formData.firstName}', '${formData.lastName}', '${formData.email}', ${formData.salary}, ${formData.regionId}, ${formData.deptId}, ${formData.roleId}, date('now'), 'Manually enrolled enterprise professional.')
      `);
      onSuccess(`${formData.firstName} ${formData.lastName}`);
    } catch (err: any) {
      setError(`Database Fault: ${err.message}`);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] bg-[#002147]/95 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-500">
      <div className="bg-white w-full max-w-2xl rounded-[3rem] p-12 shadow-2xl animate-in zoom-in-95">
        <header className="mb-10 flex justify-between items-start">
          <div>
            <h3 className="text-3xl font-black text-[#002147] uppercase tracking-tighter">Personnel Enrollment</h3>
            <p className="text-[#86BC25] text-[10px] font-black uppercase mt-1 tracking-widest">Global Talent Onboarding Protocol</p>
          </div>
          <button onClick={onCancel} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><Icons.Close /></button>
        </header>

        {error && (
          <div className="mb-8 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 text-[12px] font-bold rounded-r-xl">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">First Name</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-2xl outline-none focus:border-[#00A1DE] font-bold"
                value={formData.firstName}
                onChange={e => setFormData({...formData, firstName: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">Last Name</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-2xl outline-none focus:border-[#00A1DE] font-bold"
                value={formData.lastName}
                onChange={e => setFormData({...formData, lastName: e.target.value})}
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-slate-400">Deloitte Corporate Email</label>
            <input 
              type="email" 
              placeholder="user@deloitte.com"
              className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-2xl outline-none focus:border-[#00A1DE] font-bold"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-slate-400">Annual Salary (USD)</label>
            <input 
              type="number" 
              className="w-full bg-slate-50 border border-slate-200 px-6 py-4 rounded-2xl outline-none focus:border-[#00A1DE] font-bold"
              value={formData.salary}
              onChange={e => setFormData({...formData, salary: e.target.value})}
            />
          </div>
          <div className="grid grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">Region</label>
              <select className="w-full bg-slate-50 border border-slate-200 px-4 py-4 rounded-2xl font-bold" value={formData.regionId} onChange={e => setFormData({...formData, regionId: e.target.value})}>
                <option value="1">Asia</option>
                <option value="2">Europe</option>
                <option value="3">North America</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">Department</label>
              <select className="w-full bg-slate-50 border border-slate-200 px-4 py-4 rounded-2xl font-bold" value={formData.deptId} onChange={e => setFormData({...formData, deptId: e.target.value})}>
                <option value="1">Consulting</option>
                <option value="2">Audit & Assurance</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">Role</label>
              <select className="w-full bg-slate-50 border border-slate-200 px-4 py-4 rounded-2xl font-bold" value={formData.roleId} onChange={e => setFormData({...formData, roleId: e.target.value})}>
                <option value="1">Analyst</option>
                <option value="2">Consultant</option>
                <option value="3">Manager</option>
              </select>
            </div>
          </div>
          <div className="pt-6 flex gap-4">
            <button type="submit" className="flex-1 bg-[#86BC25] text-black font-black py-6 rounded-3xl uppercase tracking-widest hover:bg-black hover:text-white transition-all shadow-xl">Commit Record</button>
            <button type="button" onClick={onCancel} className="flex-1 bg-slate-100 text-slate-500 font-black py-6 rounded-3xl uppercase tracking-widest hover:bg-red-50 hover:text-red-500 transition-all">Abort</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const AnalyticsChart = ({ data, title }: { data: any, title: string }) => {
  const processed = useMemo(() => {
    if (!data || !data.values || data.values.length === 0) return null;
    const labels = data.values.map((v: any) => String(v[0]));
    const series = data.columns.slice(1).map((col: string, idx: number) => ({
      name: col.replace(/_/g, ' '),
      values: data.values.map((v: any) => Number(v[idx + 1]) || 0)
    }));
    const actualMax = Math.max(...series.flatMap(s => s.values), 0);
    const magnitude = Math.pow(10, Math.floor(Math.log10(actualMax || 1)));
    const interval = magnitude / 2 || 10;
    const max = Math.ceil((actualMax || 1) * 1.2 / interval) * interval;
    const steps = 5;
    const gridLines = Array.from({ length: steps + 1 }, (_, i) => (max / steps) * i);
    const isDense = labels.length > 8;
    return { labels, series, max, gridLines, isDense };
  }, [data]);

  if (!processed) return null;

  return (
    <div className="bg-white p-8 md:p-14 rounded-[4rem] border border-slate-200 shadow-[0_40px_100px_-20px_rgba(0,33,71,0.06)] animate-in fade-in duration-700 mt-8 overflow-hidden">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-14 gap-8 border-b border-slate-50 pb-12">
        <div className="space-y-2">
          <h4 className="text-[13px] font-black uppercase text-[#002147] tracking-[0.4em]">{title}</h4>
          <p className="text-[10px] font-bold text-[#86BC25] uppercase tracking-[0.2em]">Global Strategic Insight Protocol v.9</p>
        </div>
        <div className="flex flex-wrap gap-5 bg-[#002147]/5 p-5 rounded-[2rem] border border-[#002147]/5 shadow-inner">
          {processed.series.map((s, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-3.5 h-3.5 rounded-full shadow-lg" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }}></div>
              <span className="text-[11px] font-black text-[#002147] uppercase tracking-tighter">{s.name}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="relative h-[450px] overflow-x-auto overflow-y-hidden pb-24 custom-scrollbar">
        <div className="min-w-[850px] h-[350px] relative ml-20 mr-10 mt-8">
          <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
            {processed.gridLines.slice().reverse().map((val, i) => (
              <div key={i} className="w-full flex items-center gap-8 group">
                <span className="absolute -left-20 text-[11px] font-black text-slate-300 w-16 text-right tabular-nums transition-colors group-hover:text-[#002147]">
                  {Math.round(val).toLocaleString()}
                </span>
                <div className="flex-1 h-[1px] bg-slate-100 relative overflow-hidden">
                   <div className="absolute inset-0 bg-gradient-to-r from-slate-200 via-transparent to-slate-200 opacity-40"></div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex-1 h-full flex items-end gap-5 md:gap-10 px-8 relative z-10">
            {processed.labels.map((l, li) => (
              <div key={li} className="flex-1 h-full flex flex-col justify-end relative group">
                <div className="flex items-end gap-3 justify-center h-full">
                  {processed.series.map((s, si) => {
                    // COLOR LOGIC: If single series, use per-bar coloring (li). Else use per-series coloring (si).
                    const colorIndex = processed.series.length === 1 ? li : si;
                    const background = CHART_COLORS[colorIndex % CHART_COLORS.length];
                    return (
                      <div 
                        key={si} 
                        className="w-full relative group/bar" 
                        style={{ height: `${(s.values[li] / processed.max) * 100}%` }}
                      >
                        <div 
                          className="w-full h-full rounded-t-3xl transition-all duration-700 cubic-bezier(0.34, 1.56, 0.64, 1) hover:scale-x-110 shadow-[0_15px_40px_-10px_rgba(0,0,0,0.1)] border-x border-t border-white/50 ring-1 ring-black/5 flex overflow-hidden relative" 
                          style={{ background }} 
                        >
                          <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-black/30 pointer-events-none"></div>
                          <div className="absolute inset-y-0 left-0 w-[2px] bg-white/20"></div>
                        </div>
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-7 pointer-events-none opacity-0 group-hover/bar:opacity-100 transition-all z-[100] translate-y-3 group-hover/bar:translate-y-0 duration-500 scale-95 group-hover/bar:scale-100">
                           <div className="bg-[#002147]/98 backdrop-blur-3xl text-white px-8 py-6 rounded-[2.5rem] shadow-[0_30px_70px_-15px_rgba(0,0,0,0.6)] min-w-[220px] border border-white/20 ring-1 ring-white/10">
                              <p className="text-[11px] font-black text-[#86BC25] uppercase tracking-[0.2em] mb-4 border-b border-white/10 pb-4">{l}</p>
                              <div className="space-y-3">
                                  <div className="flex justify-between items-center">
                                     <span className="text-[10px] font-black text-white/40 uppercase">{s.name}</span>
                                     <span className="text-lg font-black text-white tabular-nums tracking-tighter">{s.values[li].toLocaleString()}</span>
                                  </div>
                              </div>
                           </div>
                           <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[10px] border-t-[#002147]/98 mx-auto"></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className={`absolute top-full mt-8 left-1/2 -translate-x-1/2 transition-all duration-700 ${processed.isDense ? 'origin-top-left rotate-[45deg] mt-12' : ''}`}>
                  <span className={`text-[12px] font-black text-[#002147] uppercase tracking-wide whitespace-nowrap bg-white/90 backdrop-blur-md px-5 py-2.5 rounded-full border border-slate-100 shadow-xl transition-all group-hover:bg-[#86BC25] group-hover:text-black group-hover:scale-110 group-hover:z-50 ${processed.isDense ? 'text-[11px]' : ''}`}>
                    {l}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const InsightsDashboard = () => {
  const [stats, setStats] = useState<any>(null);
  const [regionalHeadcount, setRegionalHeadcount] = useState<any[]>([]);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const globalHeadcount = dbService.query("SELECT COUNT(*) FROM employees");
        const avgSalary = dbService.query("SELECT AVG(current_salary) FROM employees");
        const byRegion = dbService.query(`
          SELECT r.region_name, COUNT(e.employee_id) as count
          FROM employees e
          JOIN regions r ON e.region_id = r.region_id
          GROUP BY r.region_name
          ORDER BY count DESC
        `);
        if (globalHeadcount?.[0] && avgSalary?.[0] && byRegion?.[0]) {
          setStats({ headcount: globalHeadcount[0].values[0][0], avgSalary: avgSalary[0].values[0][0] });
          setRegionalHeadcount(byRegion[0].values);
        }
      } catch (e) {
        console.error("Dashboard Load Error", e);
      }
    };
    loadStats();
  }, []);

  if (!stats) return <div className="h-full flex items-center justify-center animate-pulse text-slate-400 font-black tracking-widest uppercase">Syncing Global Matrix...</div>;

  return (
    <div className="space-y-16 animate-in fade-in duration-1000">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        <div className="bg-white p-12 rounded-[2.5rem] border shadow-xl border-l-[12px] border-[#002147]">
          <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Global Headcount</p>
          <h3 className="text-6xl font-black mt-4 text-[#002147] tracking-tighter">{stats.headcount.toLocaleString()}</h3>
        </div>
        <div className="bg-white p-12 rounded-[2.5rem] border shadow-xl border-l-[12px] border-[#86BC25]">
          <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Avg Personnel Cost</p>
          <h3 className="text-6xl font-black mt-4 text-[#002147] tracking-tighter">${Math.round(stats.avgSalary).toLocaleString()}</h3>
        </div>
        <div className="bg-[#00A1DE] p-12 rounded-[2.5rem] border shadow-xl border-l-[12px] border-white/20 text-white">
          <p className="text-[10px] font-black uppercase opacity-60 tracking-widest">Network Pulse</p>
          <h3 className="text-6xl font-black mt-4 tracking-tighter uppercase">ACTIVE</h3>
        </div>
      </div>
      <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl p-16">
        <header className="mb-12 border-b border-slate-50 pb-8">
           <h4 className="text-[12px] font-black uppercase text-[#002147] tracking-[0.4em] mb-2">Personnel Distribution by Geography</h4>
           <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Real-time breakdown of localized human capital</p>
        </header>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {regionalHeadcount.map(([name, count]) => (
            <div key={name} className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 hover:border-[#86BC25] transition-all group cursor-default shadow-sm">
              <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest group-hover:text-[#86BC25] transition-colors">{name}</p>
              <div className="flex items-end justify-between mt-4">
                <h5 className="text-4xl font-black text-[#002147] tabular-nums">{count}</h5>
                <p className="text-[10px] font-black uppercase opacity-30">Talent</p>
              </div>
              <div className="w-full bg-slate-200 h-1.5 mt-6 rounded-full overflow-hidden">
                <div className="h-full bg-[#86BC25] transition-all duration-1000 group-hover:scale-x-105" style={{ width: `${(count / stats.headcount) * 100}%` }}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

interface ChatBubbleProps {
  m: any;
  onSelectProfile: (id: number) => void;
  onTriggerEnrollment: () => void;
  isResolved?: boolean;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ m, onSelectProfile, onTriggerEnrollment, isResolved }) => {
  const [showSql, setShowSql] = useState(false);
  const sqlMatch = useMemo(() => m.content.match(/```sql([\s\S]*?)```/), [m.content]);
  const sqlCode = sqlMatch ? sqlMatch[1].trim() : null;
  const isIdentityNotFound = useMemo(() => {
    const hasTag = m.content.includes("IDENTITY_NOT_FOUND");
    const hasEmptyResult = !m.sqlResult || !m.sqlResult.values || m.sqlResult.values.length === 0;
    return hasTag && hasEmptyResult;
  }, [m.content, m.sqlResult]);
  const isInitiateFlow = m.content.includes("INITIATE_ENROLLMENT_FLOW");

  const cleanContent = useMemo(() => {
    let text = m.content;
    text = text.replace(/```sql[\s\S]*?```/g, ''); 
    text = text.replace(/```[\s\S]*?```/g, '');    
    text = text.replace(/CHART_RECOMMENDATION:\s*(\w+)/gi, ''); 
    text = text.replace(/IDENTITY_NOT_FOUND:/gi, ''); 
    text = text.replace(/INITIATE_ENROLLMENT_FLOW/gi, ''); 
    text = text.replace(/\bSELECT\b.*?\bFROM\b.*?;/gi, ''); 
    text = text.replace(/\bINSERT INTO\b.*?;/gi, '');
    return text.trim();
  }, [m.content]);

  return (
    <div className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-3 duration-500`}>
      <div className={`p-10 md:p-14 rounded-[3.5rem] shadow-[0_50px_100px_-20px_rgba(0,33,71,0.12)] border transition-all duration-500 ${isResolved ? 'opacity-40 grayscale' : 'opacity-100'} ${m.role === 'user' ? 'bg-[#00A1DE] text-white border-[#00A1DE] max-w-[80%]' : 'bg-white text-slate-900 border-slate-50 w-full lg:max-w-[99%] shadow-[0_50px_100px_-20px_rgba(0,33,71,0.08)]'}`}>
        {isIdentityNotFound && !isResolved && (
          <div className="mb-10 px-10 py-7 rounded-[2rem] border-2 border-amber-200 bg-amber-50 text-amber-800 text-[13px] font-black uppercase tracking-widest shadow-lg flex items-center gap-6">
            <div className="w-4 h-4 bg-amber-500 rounded-full animate-ping"></div>
            Access Protocol Exception: Subject Not Found
          </div>
        )}
        {cleanContent && <p className="whitespace-pre-wrap leading-relaxed font-medium text-[18px] text-[#002147]/95">{cleanContent}</p>}
        {isInitiateFlow && !isResolved && (
          <div className="mt-12">
            <button onClick={onTriggerEnrollment} className="flex items-center gap-5 bg-[#86BC25] text-black px-16 py-8 rounded-[3rem] font-black uppercase tracking-[0.3em] shadow-2xl hover:bg-black hover:text-white transition-all transform hover:scale-[1.04] active:scale-95">
              <Icons.Add /> Open Enrollment Protocol
            </button>
          </div>
        )}
        {sqlCode && m.role === 'model' && (
          <div className="mt-12 pt-12 border-t border-slate-100">
            <button onClick={() => setShowSql(!showSql)} className="flex items-center gap-5 px-10 py-6 rounded-full bg-slate-50 border border-slate-200 text-[12px] font-black uppercase tracking-widest text-[#002147] hover:bg-[#86BC25] hover:border-[#86BC25] transition-all group shadow-md">
              <Icons.Code /> {showSql ? 'Encrypt Engine Logic' : 'Inspect Logic Parameters'}
            </button>
            {showSql && (
              <div className="mt-10 p-12 bg-[#002147] text-[#86BC25] rounded-[3rem] font-mono text-[13px] overflow-x-auto border border-white/10 shadow-3xl animate-in slide-in-from-top-6 ring-2 ring-black/20">
                <code>{sqlCode}</code>
              </div>
            )}
          </div>
        )}
        {m.sqlResult && m.sqlResult.values.length > 0 && (
          <div className="mt-14 border border-slate-200 rounded-[3rem] bg-slate-50/50 overflow-x-auto shadow-[inset_0_20px_50px_rgba(0,33,71,0.03)] custom-scrollbar">
            <table className="w-full text-left text-[16px] min-w-[800px]">
              <thead className="bg-[#002147] text-white text-[11px] font-black uppercase tracking-[0.4em]">
                <tr>{m.sqlResult.columns.map((c: any) => <th key={c} className="px-12 py-8 whitespace-nowrap">{c.replace('_', ' ')}</th>)}</tr>
              </thead>
              <tbody>
                {m.sqlResult.values.map((row: any[], ri: number) => {
                  const eidIndex = m.sqlResult.columns.findIndex(c => c.toLowerCase().includes('id'));
                  const nameIndex = m.sqlResult.columns.findIndex(c => c.toLowerCase().includes('name'));
                  const emailIndex = m.sqlResult.columns.findIndex(c => c.toLowerCase().includes('email'));
                  return (
                    <tr key={ri} className="border-b border-slate-100 group transition-all hover:bg-white hover:scale-[1.005]">
                      {row.map((val, vi) => (
                        <td key={vi} className={`px-12 py-7 font-bold transition-colors ${vi === emailIndex ? 'text-slate-400 text-sm font-mono tracking-tight' : 'text-[#00A1DE] group-hover:text-[#002147]'}`}>
                          {vi === nameIndex && eidIndex !== -1 ? (
                            <button onClick={() => onSelectProfile(row[eidIndex])} className="underline decoration-slate-200 decoration-4 underline-offset-8 hover:decoration-[#86BC25] hover:text-[#86BC25] transition-all whitespace-nowrap">{val}</button>
                          ) : (typeof val === 'number' && m.sqlResult.columns[vi].toLowerCase().includes('salary') ? `$${val.toLocaleString()}` : val)}
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
        {m.chart && m.sqlResult && (
          <div className="mt-14">
            <AnalyticsChart data={m.sqlResult} title="Strategic Performance Matrix" />
          </div>
        )}
      </div>
    </div>
  );
};

const DirectoryTable = ({ data, onSelect }: { data: any, onSelect: (id: number) => void }) => {
  if (!data) return null;
  return (
    <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-700">
      <header className="p-12 bg-[#002147] text-white flex justify-between items-end">
        <div>
          <h3 className="text-3xl font-black uppercase tracking-tighter">Personnel Directory</h3>
          <p className="text-[#86BC25] text-[11px] font-black uppercase mt-2 tracking-[0.2em]">Validated Human Capital Ledger</p>
        </div>
        <div className="text-right">
           <p className="text-[10px] font-black uppercase opacity-40">Total Records</p>
           <p className="text-2xl font-black text-[#86BC25]">{data.values.length}</p>
        </div>
      </header>
      <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
        <table className="w-full text-left border-collapse min-w-[1200px]">
          <thead className="bg-slate-50 border-b border-slate-100 sticky top-0 z-10">
            <tr>{data.columns.map((c: string) => <th key={c} className="px-10 py-6 text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] whitespace-nowrap">{c.replace('_', ' ')}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {data.values.map((row: any[], ri: number) => (
              <tr key={ri} className="hover:bg-slate-50 transition-all group cursor-pointer" onClick={() => onSelect(row[0])}>
                {row.map((val, vi) => (
                  <td key={vi} className="px-10 py-5 text-[14px] font-bold text-[#00A1DE] group-hover:text-[#002147] whitespace-nowrap transition-colors">
                    {typeof val === 'number' && (data.columns[vi].toLowerCase().includes('salary') || data.columns[vi].toLowerCase().includes('revenue')) ? `$${val.toLocaleString()}` : val}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const ProfileOverlay = ({ id, onClose }: { id: number, onClose: () => void }) => {
  const [profile, setProfile] = useState<any>(null);
  useEffect(() => {
    const fetchProfile = async () => {
      const res = dbService.query(`
        SELECT e.*, r.region_name, d.department_name, ro.role_name
        FROM employees e
        JOIN regions r ON e.region_id = r.region_id
        JOIN departments d ON e.department_id = d.department_id
        JOIN roles ro ON e.role_id = ro.role_id
        WHERE e.employee_id = ${id}
      `);
      if (res?.[0]?.values?.[0]) {
        const vals = res[0].values[0];
        const cols = res[0].columns;
        const mapped = cols.reduce((acc: any, col: string, idx: number) => ({ ...acc, [col]: vals[idx] }), {});
        setProfile(mapped);
      }
    };
    fetchProfile();
  }, [id]);

  if (!profile) return null;

  return (
    <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-md flex items-center justify-end animate-in fade-in duration-300">
      <div className="w-full max-w-3xl h-full bg-white shadow-2xl animate-in slide-in-from-right duration-500 overflow-y-auto">
        <header className="p-12 bg-[#002147] text-white flex justify-between items-start sticky top-0 z-10">
          <div>
            <h3 className="text-4xl font-black uppercase tracking-tighter">{profile.first_name} {profile.last_name}</h3>
            <p className="text-[#86BC25] text-xs font-black uppercase tracking-[0.2em] mt-2">{profile.role_name} / {profile.department_name}</p>
          </div>
          <button onClick={onClose} className="p-4 hover:bg-white/10 rounded-full transition-colors"><Icons.Close /></button>
        </header>
        <div className="p-16 space-y-12">
          <section>
            <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6 border-b pb-2">Operational Identity</h4>
            <div className="grid grid-cols-2 gap-10">
              <div><p className="text-[9px] font-black text-slate-400 uppercase">Corporate Email</p><p className="text-lg font-bold text-[#00A1DE] mt-1">{profile.deloitte_email}</p></div>
              <div><p className="text-[9px] font-black text-slate-400 uppercase">Region</p><p className="text-lg font-bold text-[#002147] mt-1">{profile.region_name}</p></div>
            </div>
          </section>
          <section>
            <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6 border-b pb-2">Financial Remuneration</h4>
            <div className="bg-slate-50 p-10 rounded-3xl border border-slate-100 flex items-center justify-between">
              <div><p className="text-[10px] font-black text-slate-400 uppercase">Base Annual Salary</p><p className="text-5xl font-black text-[#002147] mt-2 tracking-tighter">${profile.current_salary.toLocaleString()}</p></div>
              <div className="text-right"><p className="text-[10px] font-black text-[#86BC25] uppercase">Pay Grade</p><p className="text-xl font-bold text-[#002147] mt-1">Tier 1 Elite</p></div>
            </div>
          </section>
          <section>
            <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6 border-b pb-2">Personnel Biography</h4>
            <p className="text-lg font-medium leading-relaxed text-slate-700">{profile.biography}</p>
          </section>
          <section>
            <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6 border-b pb-2">Core Competencies</h4>
            <div className="flex flex-wrap gap-4">
              {profile.skills?.split(',').map((s: string) => <span key={s} className="px-6 py-3 bg-[#86BC25]/10 text-[#86BC25] rounded-full text-[11px] font-black uppercase tracking-widest border border-[#86BC25]/20">{s.trim()}</span>)}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const [tab, setTab] = useState<'insights' | 'ai' | 'personnel'>('insights');
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [directoryData, setDirectoryData] = useState<any>(null);
  const [selectedProfileId, setSelectedProfileId] = useState<number | null>(null);
  const [showEnrollment, setShowEnrollment] = useState(false);
  const [resolvedIndices, setResolvedIndices] = useState<Set<number>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { 
    dbService.init().then(() => { 
      setIsReady(true); 
      refreshDirectory(); 
    }); 
  }, []);

  const refreshDirectory = () => {
    const res = dbService.query(`
      SELECT e.employee_id, e.first_name || ' ' || e.last_name as full_name, r.region_name as region, d.department_name as department, ro.role_name as role, e.deloitte_email, e.current_salary as salary
      FROM employees e JOIN regions r ON e.region_id = r.region_id JOIN departments d ON e.department_id = d.department_id JOIN roles ro ON e.role_id = ro.role_id ORDER BY e.employee_id ASC
    `);
    if (res?.[0]) setDirectoryData(res[0]);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const onSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    const userQuery = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userQuery }]);
    setLoading(true);
    const msgId = Date.now();
    setMessages(prev => [...prev, { id: msgId, role: 'model', content: '', streaming: true }]);

    const processMessageContent = async (msgContent: string, currentMsgId: number, isRetry: boolean) => {
      const sqlMatch = msgContent.match(/```sql([\s\S]*?)```/);
      const chartMatch = msgContent.match(/CHART_RECOMMENDATION:\s*(\w+)/i);
      if (sqlMatch) {
        const sql = sqlMatch[1].trim();
        try {
          const resList = dbService.query(sql);
          const res = resList?.[0];
          if (sql.toLowerCase().startsWith('select') && (!res || !res.values || res.values.length === 0) && !isRetry) {
             const retryStream = geminiService.generateResponseStream(`SYSTEM_INTERNAL: Target identification failed (0 results) for "${userQuery}". ACTION: Check if input matches 'deloitte_email' exactly or via LIKE. Re-querying core index...`, [...messages, { role: 'user', content: userQuery }]);
             let retryFull = "";
             for await (const c of retryStream) {
               retryFull += c;
               setMessages(p => p.map(m => m.id === currentMsgId ? { ...m, content: retryFull } : m));
             }
             return await processMessageContent(retryFull, currentMsgId, true);
          }
          const detectedChart = chartMatch ? chartMatch[1].toLowerCase() : null;
          setMessages(p => p.map(m => m.id === currentMsgId ? { ...m, sqlResult: res, chart: detectedChart, streaming: false } : m));
        } catch (err: any) {
          setMessages(p => p.map(m => m.id === currentMsgId ? { ...m, content: `SQL_TRANSIT_ERROR: ${err.message}`, streaming: false } : m));
        }
      } else {
        setMessages(p => p.map(m => m.id === currentMsgId ? { ...m, streaming: false } : m));
      }
    };

    try {
      let fullResponse = "";
      const stream = geminiService.generateResponseStream(userQuery, messages);
      for await (const chunk of stream) {
        fullResponse += chunk;
        setMessages(p => p.map(m => m.id === msgId ? { ...m, content: fullResponse } : m));
      }
      await processMessageContent(fullResponse, msgId, false);
    } catch (err: any) {
      setMessages(p => p.map(m => m.id === msgId ? { ...m, content: `SYSTEM_BRIDGE_FAULT: ${err.message}`, streaming: false } : m));
    } finally {
      setLoading(false);
    }
  };

  const handleEnrollmentSuccess = (name: string) => {
    setShowEnrollment(false);
    refreshDirectory();
    setMessages(prev => {
      const updatedMessages = [...prev];
      updatedMessages.forEach((msg, idx) => {
        if (msg.content && (msg.content.includes("IDENTITY_NOT_FOUND") || msg.content.includes("INIT_ENROLLMENT_FLOW"))) {
          setResolvedIndices(prevRes => {
            const next = new Set(prevRes);
            next.add(idx);
            return next;
          });
        }
      });
      return [...updatedMessages, { role: 'model', content: `SUCCESS: Personnel record "${name}" has been synchronized.` }];
    });
  };

  if (!isReady) return <div className="h-screen flex items-center justify-center bg-[#002147] text-[#86BC25] font-black uppercase tracking-[0.5em] animate-pulse">Deloitte Core Initialising...</div>;

  return (
    <div className="flex h-screen bg-[#f8fafc] text-[#002147] font-sans selection:bg-[#86BC25]/30 overflow-hidden">
      <aside className="w-80 bg-black text-white p-10 flex flex-col shrink-0 shadow-2xl z-20">
        <div className="flex items-center gap-5 mb-20 group cursor-default"><Icons.Deloitte /><h1 className="text-3xl font-black uppercase tracking-tighter group-hover:text-[#86BC25] transition-colors">Deloitte</h1></div>
        <nav className="space-y-6">
          <button onClick={() => setTab('insights')} className={`w-full flex items-center gap-5 px-8 py-6 rounded-[2rem] transition-all transform hover:scale-105 ${tab === 'insights' ? 'bg-[#86BC25] text-black shadow-xl' : 'text-slate-400 hover:bg-white/5'}`}><Icons.Dashboard /> <span className="text-[12px] font-black uppercase tracking-[0.2em]">Insights</span></button>
          <button onClick={() => setTab('ai')} className={`w-full flex items-center gap-5 px-8 py-6 rounded-[2rem] transition-all transform hover:scale-105 ${tab === 'ai' ? 'bg-[#86BC25] text-black shadow-xl' : 'text-slate-400 hover:bg-white/5'}`}><Icons.AI /> <span className="text-[12px] font-black uppercase tracking-[0.2em]">Intelligence</span></button>
          <button onClick={() => setTab('personnel')} className={`w-full flex items-center gap-5 px-8 py-6 rounded-[2rem] transition-all transform hover:scale-105 ${tab === 'personnel' ? 'bg-[#86BC25] text-black shadow-xl' : 'text-slate-400 hover:bg-white/5'}`}><Icons.Directory /> <span className="text-[12px] font-black uppercase tracking-[0.2em]">Personnel</span></button>
        </nav>
      </aside>
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-28 bg-white border-b px-16 flex items-center justify-between shadow-sm z-10">
          <div className="space-y-1"><h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400">Secure Protocol / {tab}</h2><p className="text-xl font-black text-[#002147] uppercase tracking-tighter">{tab === 'insights' ? 'Executive Insights' : tab === 'ai' ? 'Intelligence Terminal' : 'Human Capital Ledger'}</p></div>
          <div className="flex items-center gap-4 bg-slate-50 px-6 py-3 rounded-full border border-slate-100"><div className="w-2 h-2 bg-[#86BC25] rounded-full animate-pulse"></div><span className="text-[10px] font-black uppercase tracking-widest">Network Verified</span></div>
        </header>
        <div className="flex-1 overflow-y-auto p-16 bg-[#fcfdfe] scroll-smooth">
          {tab === 'personnel' ? <DirectoryTable data={directoryData} onSelect={(id) => setSelectedProfileId(id)} /> : tab === 'insights' ? <InsightsDashboard /> : (
            <div className="max-w-screen-2xl mx-auto h-full flex flex-col">
              <div className="flex-1 overflow-y-auto space-y-16 pb-24 px-4">
                {messages.length === 0 && <div className="h-full flex flex-col items-center justify-center opacity-30 py-48 text-center grayscale select-none pointer-events-none"><Icons.AI /><p className="mt-8 text-[13px] font-black uppercase tracking-[0.6em]">Awaiting Intelligence Request</p></div>}
                {messages.map((m, i) => <ChatBubble key={i} m={m} onSelectProfile={(id) => setSelectedProfileId(id)} onTriggerEnrollment={() => setShowEnrollment(true)} isResolved={resolvedIndices.has(i)} />)}
                <div ref={scrollRef} />
              </div>
              <form onSubmit={onSend} className="sticky bottom-0 bg-gradient-to-t from-[#fcfdfe] via-[#fcfdfe] to-transparent pt-12 pb-8 px-4">
                <div className="bg-white border-[3px] border-[#002147]/10 p-5 rounded-[4rem] shadow-[0_40px_80px_-15px_rgba(0,33,71,0.15)] flex items-center focus-within:border-[#00A1DE] transition-all transform ring-4 ring-slate-100/50">
                  <input type="text" value={input} onChange={e => setInput(e.target.value)} placeholder="Query directory, analyze regional trends, or execute personnel protocols..." className="flex-1 px-8 py-3 outline-none text-[20px] font-bold text-slate-900 placeholder:text-slate-300 bg-transparent" />
                  <button disabled={loading} type="submit" className="bg-[#86BC25] text-black font-black px-16 py-7 rounded-[3rem] uppercase tracking-widest shadow-2xl hover:bg-[#002147] hover:text-white transition-all active:scale-95 disabled:opacity-50">{loading ? 'Synthesizing...' : 'Execute Protocol'}</button>
                </div>
              </form>
            </div>
          )}
        </div>
      </main>
      {selectedProfileId && <ProfileOverlay id={selectedProfileId} onClose={() => setSelectedProfileId(null)} />}
      {showEnrollment && <EnrollmentForm onCancel={() => setShowEnrollment(false)} onSuccess={handleEnrollmentSuccess} />}
    </div>
  );
};

createRoot(document.getElementById('root')!).render(<App />);
