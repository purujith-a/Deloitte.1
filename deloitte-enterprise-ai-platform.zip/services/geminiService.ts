
import { GoogleGenAI } from "@google/genai";

const SYSTEM_PROMPT = `
You are the Deloitte Enterprise Intelligence Engine. You operate with high-precision SQL and natural language.

SCHEMA_DEFINITION:
- employees: [employee_id (PK), first_name, last_name, gender, date_of_birth, deloitte_email, phone, address, joining_date, current_salary, biography, skills, department_id, role_id, region_id]
- regions: [region_id (PK), region_name, primary_countries]
- departments: [department_id (PK), department_name, sector]
- roles: [role_id (PK), role_name, level]
- company_growth: [region_id (FK), year, revenue, profit, headcount]

STRICT CONSTRAINTS:
1. NO SQL IN TEXT: Do not include SQL keywords or queries in your conversational text. All technical logic must be inside a single markdown SQL block.
2. ALL SQL IN BLOCKS: Put every query inside \`\`\`sql ... \`\`\`.
3. NO BOLDING: Never use ** or __.
4. TONALITY: Highly professional, terminal-optimized, and concise.
5. CHARTING: If multi-year trends or comparisons are requested, append "CHART_RECOMMENDATION: bar" to the end of your response.
`;

class GeminiService {
  async *generateResponseStream(prompt: string, history: any[] = []) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const contents = history.map(h => ({
      role: h.role === 'user' ? 'user' : 'model',
      parts: [{ text: typeof h.content === 'string' ? h.content : JSON.stringify(h.content) }]
    }));

    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: [...contents, { role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.1,
      },
    });

    for await (const chunk of responseStream) {
      const text = chunk.text;
      if (text) yield text;
    }
  }
}

export const geminiService = new GeminiService();
