
declare var initSqlJs: any;

class DatabaseService {
  private db: any = null;

  async init() {
    if (this.db) return;

    const SQL = await initSqlJs({
      locateFile: (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/sql-wasm.wasm`
    });

    this.db = new SQL.Database();

    this.db.run(`
      CREATE TABLE regions (
          region_id INTEGER PRIMARY KEY AUTOINCREMENT,
          region_name TEXT NOT NULL,
          primary_countries TEXT
      );

      CREATE TABLE departments (
          department_id INTEGER PRIMARY KEY AUTOINCREMENT,
          department_name TEXT NOT NULL,
          sector TEXT
      );

      CREATE TABLE roles (
          role_id INTEGER PRIMARY KEY AUTOINCREMENT,
          role_name TEXT NOT NULL,
          level TEXT
      );

      CREATE TABLE employees (
          employee_id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          gender TEXT,
          date_of_birth TEXT,
          deloitte_email TEXT UNIQUE,
          phone TEXT,
          address TEXT,
          joining_date TEXT,
          current_salary INTEGER,
          biography TEXT,
          skills TEXT,
          department_id INTEGER,
          role_id INTEGER,
          region_id INTEGER,
          FOREIGN KEY(department_id) REFERENCES departments(department_id),
          FOREIGN KEY(role_id) REFERENCES roles(role_id),
          FOREIGN KEY(region_id) REFERENCES regions(region_id)
      );

      CREATE TABLE company_growth (
          region_id INTEGER,
          year INTEGER,
          revenue REAL,
          profit REAL,
          headcount INTEGER,
          PRIMARY KEY (region_id, year),
          FOREIGN KEY(region_id) REFERENCES regions(region_id)
      );

      CREATE TABLE human_resources (
          region_id INTEGER,
          year INTEGER,
          hires INTEGER,
          exits INTEGER,
          hr_cost REAL,
          PRIMARY KEY (region_id, year),
          FOREIGN KEY(region_id) REFERENCES regions(region_id)
      );

      CREATE TABLE financials (
          region_id INTEGER,
          year INTEGER,
          earned REAL,
          spent REAL,
          invested REAL,
          PRIMARY KEY (region_id, year),
          FOREIGN KEY(region_id) REFERENCES regions(region_id)
      );
    `);

    this.seedData();
  }

  private seedData() {
    const regionData = [
      ["Asia", "China, India, Japan, Singapore"],
      ["Europe", "UK, Germany, France, Italy"],
      ["North America", "USA, Canada, Mexico"],
      ["South America", "Brazil, Argentina, Chile"],
      ["Middle East", "UAE, Saudi Arabia, Qatar"],
      ["Africa", "South Africa, Nigeria, Kenya"],
      ["Australia", "Australia, New Zealand"]
    ];
    
    const deptData = [
      ["Consulting", "Strategy"],
      ["Audit & Assurance", "Finance"],
      ["Tax & Legal", "Legal"],
      ["Risk Advisory", "Compliance"],
      ["Financial Advisory", "M&A"]
    ];

    const roleData = [
      ["Analyst", "Level 1"],
      ["Consultant", "Level 2"],
      ["Manager", "Level 3"],
      ["Director", "Level 4"],
      ["Partner", "Level 5"]
    ];

    this.db.run("BEGIN TRANSACTION");

    regionData.forEach(([name, countries]) => 
      this.db.run("INSERT INTO regions (region_name, primary_countries) VALUES (?, ?)", [name, countries])
    );
    deptData.forEach(([name, sector]) => 
      this.db.run("INSERT INTO departments (department_name, sector) VALUES (?, ?)", [name, sector])
    );
    roleData.forEach(([name, level]) => 
      this.db.run("INSERT INTO roles (role_name, level) VALUES (?, ?)", [name, level])
    );

    const firstNames = ["James", "Mary", "Reka", "Noah", "Emma", "Oliver", "Sophia", "John", "Sarah", "Michael", "Arjun", "Li", "Hans", "Elena", "Fatima", "Klaus", "Sanya", "David", "Lucia"];
    const lastNames = ["Adams", "Smith", "Johnson", "Williams", "Deloitte", "Garcia", "Miller", "Davis", "Chen", "Kumar", "Muller", "Rossi", "Khan", "Okonkwo", "Sato"];
    
    // DETERMINISTIC ENTRIES to satisfy test cases
    const fixedProfiles = [
        { fn: "Michael", ln: "Chen", email: "michael.chen.0@deloitte.com", regId: 1, deptId: 1, roleId: 1 },
        { fn: "Sarah", ln: "Miller", email: "sarah.miller.1@deloitte.com", regId: 2, deptId: 2, roleId: 3 },
        { fn: "John", ln: "Davis", email: "john.davis.2@deloitte.com", regId: 3, deptId: 1, roleId: 4 }
    ];

    fixedProfiles.forEach(p => {
        const joined = "2020-01-01";
        const salary = 120000;
        const bio = "Key enterprise professional assigned to strategic high-impact projects.";
        const skills = "SQL, Leadership, Analytics";
        this.db.run(`
            INSERT INTO employees (first_name, last_name, gender, date_of_birth, deloitte_email, phone, address, joining_date, current_salary, biography, skills, department_id, role_id, region_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [p.fn, p.ln, 'M', '1990-01-01', p.email, '+1-555-0000', '123 Deloitte Plaza', joined, salary, bio, skills, p.deptId, p.roleId, p.regId]
        );
    });

    // Random remaining profiles up to 1000
    for (let i = fixedProfiles.length; i < 1000; i++) {
      const fn = firstNames[Math.floor(Math.random() * firstNames.length)];
      const ln = lastNames[Math.floor(Math.random() * lastNames.length)];
      const regId = Math.floor(Math.random() * 7) + 1;
      const deptId = Math.floor(Math.random() * 5) + 1;
      const roleId = Math.floor(Math.random() * 5) + 1;
      const joinedYear = 2015 + Math.floor(Math.random() * 11);
      const joined = `${joinedYear}-${String(Math.floor(Math.random()*12)+1).padStart(2,'0')}-01`;
      const salary = 65000 + (roleId * 22000) + (Math.random() * 10000);
      const bio = "An experienced professional at Deloitte Global, specialized in regional transformation and strategic excellence.";
      const skillSet = ["SQL", "Strategic Planning", "Leadership", "Financial Modeling", "Data Analytics"].sort(() => 0.5 - Math.random()).slice(0, 3).join(", ");

      this.db.run(`
        INSERT INTO employees (first_name, last_name, gender, date_of_birth, deloitte_email, phone, address, joining_date, current_salary, biography, skills, department_id, role_id, region_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [fn, ln, Math.random() > 0.5 ? 'M' : 'F', '1990-01-01', `${fn.toLowerCase()}.${ln.toLowerCase()}.${i}@deloitte.com`, `+1-555-${String(i).padStart(4,'0')}`, '123 Deloitte Plaza', joined, salary, bio, skillSet, deptId, roleId, regId]
      );
    }

    // Historical analytics data (2015-2025)
    for (let r = 1; r <= 7; r++) {
      for (let y = 2015; y <= 2025; y++) {
        const baseRev = 800 + (r * 150);
        const growth = 1 + ((y - 2015) * 0.12);
        const revenue = (baseRev * growth) + (Math.random() * 100);
        const profit = revenue * (0.15 + (Math.random() * 0.05));
        const hc = 400 + ((y - 2015) * 60) + (r * 20);

        this.db.run("INSERT INTO company_growth (region_id, year, revenue, profit, headcount) VALUES (?, ?, ?, ?, ?)", [r, y, revenue, profit, hc]);
        this.db.run("INSERT INTO human_resources (region_id, year, hires, exits, hr_cost) VALUES (?, ?, ?, ?, ?)", [r, y, 40, 8, revenue * 0.35]);
        this.db.run("INSERT INTO financials (region_id, year, earned, spent, invested) VALUES (?, ?, ?, ?, ?)", [r, y, revenue, revenue * 0.7, revenue * 0.12]);
      }
    }

    this.db.run("COMMIT");
  }

  query(sql: string) {
    try {
      const result = this.db.exec(sql);
      return result;
    } catch (err) {
      console.error("SQL Error:", err);
      throw err;
    }
  }
}

export const dbService = new DatabaseService();
