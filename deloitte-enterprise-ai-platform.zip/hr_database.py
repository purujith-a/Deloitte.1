
import sqlite3
import random
import os

class HRDatabase:
    def __init__(self, db_path="hr_enterprise.db"):
        self.db_path = db_path

    def initialize(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Comprehensive HR Schema updated to match instructions
        cursor.executescript("""
            CREATE TABLE IF NOT EXISTS regions (
                region_id INTEGER PRIMARY KEY AUTOINCREMENT,
                region_name TEXT NOT NULL,
                primary_countries TEXT
            );
            CREATE TABLE IF NOT EXISTS employees (
                employee_id INTEGER PRIMARY KEY AUTOINCREMENT, 
                first_name TEXT, 
                last_name TEXT, 
                deloitte_email TEXT, 
                phone TEXT, 
                address TEXT, 
                current_salary INTEGER, 
                joining_date TEXT,
                region_id INTEGER,
                FOREIGN KEY(region_id) REFERENCES regions(region_id)
            );
            CREATE TABLE IF NOT EXISTS new_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                name TEXT, email TEXT, phone TEXT, address TEXT, 
                salary INTEGER, joining_date TEXT
            );
            CREATE TABLE IF NOT EXISTS departments (
                department_id INTEGER PRIMARY KEY AUTOINCREMENT,
                department_name TEXT,
                sector TEXT
            );
            CREATE TABLE IF NOT EXISTS roles (
                role_id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_name TEXT,
                level TEXT
            );
            CREATE TABLE IF NOT EXISTS skills (
                employee_id INTEGER, skill_name TEXT, proficiency TEXT
            );
            CREATE TABLE IF NOT EXISTS company_growth (
                region_id INTEGER,
                year INTEGER,
                revenue REAL,
                profit REAL,
                headcount INTEGER,
                PRIMARY KEY (region_id, year),
                FOREIGN KEY(region_id) REFERENCES regions(region_id)
            );
            
            CREATE INDEX IF NOT EXISTS idx_emp_name ON employees(first_name);
            CREATE INDEX IF NOT EXISTS idx_cg_year ON company_growth(year);
        """)

        # Check if seeding is required
        cursor.execute("SELECT count(*) FROM employees")
        if cursor.fetchone()[0] == 0:
            self._seed_data(cursor)
        
        conn.commit()
        conn.close()

    def _seed_data(self, cursor):
        """Generates 1,000 fake enterprise profiles and analytics data."""
        region_data = [
            ("Asia", "China, India, Japan"), ("Europe", "UK, Germany, France"),
            ("North America", "USA, Canada"), ("South America", "Brazil"),
            ("Middle East", "UAE"), ("Africa", "South Africa"), ("Australia", "Australia")
        ]
        for r_name, countries in region_data:
            cursor.execute("INSERT INTO regions (region_name, primary_countries) VALUES (?, ?)", (r_name, countries))

        first_names = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda", "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph"]
        last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]
        
        records = []
        for i in range(1000):
            fn = random.choice(first_names)
            ln = random.choice(last_names)
            email = f"{fn.lower()}.{ln.lower()}.{i}@deloitte.com"
            phone = f"555-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
            address = f"{random.randint(101, 999)} Enterprise St"
            salary = random.randint(65000, 245000)
            year = random.randint(2015, 2024)
            date = f"{year}-{random.randint(1,12):02d}-01"
            reg_id = random.randint(1, 7)
            records.append((fn, ln, email, phone, address, salary, date, reg_id))

        cursor.executemany("INSERT INTO employees (first_name, last_name, deloitte_email, phone, address, current_salary, joining_date, region_id) VALUES (?,?,?,?,?,?,?,?)", records)
        
        # Seed analytics data 2015-2025
        for r_id in range(1, 8):
            for year in range(2015, 2026):
                revenue = 1000 + (year - 2015) * 150 + random.randint(0, 200)
                profit = revenue * 0.2
                hc = 500 + (year - 2015) * 40
                cursor.execute("INSERT INTO company_growth VALUES (?, ?, ?, ?, ?)", (r_id, year, revenue, profit, hc))

    def query(self, sql):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(sql)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            raise e
        finally:
            conn.close()

    def execute(self, sql):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        try:
            cursor.execute(sql)
            conn.commit()
        finally:
            conn.close()
