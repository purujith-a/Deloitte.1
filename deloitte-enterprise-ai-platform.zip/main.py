
import os
import sys
import time
from hr_database import HRDatabase
from hr_ai import HRAgent

# Enterprise Terminal Styling
CLR_HEADER = "\033[94m" # Blue
CLR_SUCCESS = "\033[92m" # Green
CLR_ERROR = "\033[91m" # Red
CLR_DIM = "\033[2m"
CLR_RESET = "\033[0m"
CLR_BOLD = "\033[1m"

class HRTerminal:
    def __init__(self):
        self.db = HRDatabase()
        self.agent = HRAgent()
        self.onboarding_fields = [
            "Full Name", "Email", "Phone", "Address", "Salary", "Joining Date (YYYY-MM-DD)"
        ]

    def clear(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def log(self, text, style=CLR_SUCCESS, bold=False):
        prefix = CLR_BOLD if bold else ""
        print(f"{prefix}{style}{text}{CLR_RESET}")

    def run_enrollment_protocol(self):
        """Interactive multi-step CLI enrollment for new employees."""
        self.log("\n[SYSTEM_ALERT] INITIATING PERSONNEL ENROLLMENT PROTOCOL", CLR_HEADER, bold=True)
        self.log("Please provide the following data points:\n", CLR_DIM)
        
        data = {}
        for field in self.onboarding_fields:
            try:
                val = input(f"{CLR_HEADER}[INPUT REQUIRED] {field}:{CLR_RESET} ").strip()
                if not val:
                    val = "N/A"
                key = field.lower().split(' ')[0] # Simple key mapping
                data[key] = val
            except KeyboardInterrupt:
                self.log("\n[ABORTED] Enrollment cancelled by operator.", CLR_ERROR)
                return

        self.log("\nCOMMITTING TRANSACTION TO STAGING SEGMENT...", CLR_DIM)
        try:
            # We map 'Full' to 'name' and ensure salary is numeric for the SQL
            salary_raw = data.get('salary', '0').replace(',', '')
            salary = int(salary_raw) if salary_raw.isdigit() else 0
            
            sql = f"""
                INSERT INTO new_users (name, email, phone, address, salary, joining_date) 
                VALUES ('{data.get('full', 'Unknown')}', '{data.get('email', 'N/A')}', 
                '{data.get('phone', 'N/A')}', '{data.get('address', 'N/A')}', 
                {salary}, '{data.get('joining', '2025-01-01')}')
            """
            self.db.execute(sql)
            time.sleep(1) # Simulation of network latency
            self.log("SUCCESS: Record appended to 'new_users' table.", CLR_SUCCESS, bold=True)
        except Exception as e:
            self.log(f"SQL_COMMIT_FAILURE: {str(e)}", CLR_ERROR)

    def start(self):
        self.clear()
        self.log("="*60, CLR_HEADER)
        self.log("DELOITTE ENTERPRISE HR INTELLIGENCE SYSTEM [V3.0]", CLR_HEADER, bold=True)
        self.log("="*60, CLR_HEADER)
        self.log("BOOTING SYSTEM KERNEL...", CLR_DIM)
        
        try:
            self.db.initialize()
            self.log("LOCAL_DB_MOUNT: ONLINE (SQLITE3)")
            self.log("AI_LOGIC_BRIDGE: CONNECTED (GEMINI-3)")
            self.log("-" * 60)
            self.log("Ready for natural language instructions. (Type 'exit' to logout)")
        except Exception as e:
            self.log(f"CRITICAL_SYSTEM_ERROR: {str(e)}", CLR_ERROR, bold=True)
            return

        while True:
            try:
                query = input(f"\n{CLR_HEADER}HR_SH>{CLR_RESET} ").strip()
                
                if not query:
                    continue
                if query.lower() in ['exit', 'quit', 'logout']:
                    self.log("TERMINATING SESSION... GOODBYE.")
                    break
                if query.lower() == 'clear':
                    self.clear()
                    continue

                print(f"{CLR_DIM}_AI is analyzing secure database...{CLR_RESET}", end="\r")
                
                ai_response = self.agent.get_response(query)
                
                # Check if the AI wants to trigger the enrollment UI
                if "ENROLLMENT_MODE_INITIATED" in ai_response:
                    self.run_enrollment_protocol()
                    continue

                # Check for SQL blocks in response
                if "```sql" in ai_response:
                    try:
                        sql = ai_response.split("```sql")[1].split("```")[0].strip()
                        # Execute the SQL
                        results = self.db.query(sql)
                        
                        # Generate a final summary of the data
                        summary_prompt = f"User asked: {query}\nDatabase returned: {str(results)}\nSummarize this data for the user in a professional terminal format."
                        summary = self.agent.get_response(summary_prompt, is_summary=True)
                        self.log(summary)
                    except Exception as e:
                        self.log(f"DATA_RETRIEVAL_ERROR: {str(e)}", CLR_ERROR)
                else:
                    # Generic AI response (clarifications, etc)
                    self.log(ai_response)

            except KeyboardInterrupt:
                print("\n")
                self.log("INTERRUPT DETECTED. USE 'EXIT' TO CLOSE SECURELY.", CLR_DIM)
            except Exception as e:
                self.log(f"UNHANDLED_EXCEPTION: {str(e)}", CLR_ERROR)

if __name__ == "__main__":
    if not os.environ.get("API_KEY"):
        print("\033[91m[CRITICAL] Environment variable 'API_KEY' not found.\033[0m")
        print("Please set your API key: export API_KEY='your-key-here'")
        sys.exit(1)
        
    app = HRTerminal()
    app.start()
