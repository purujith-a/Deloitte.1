# Enterprise HR Intelligence System (CLI)

A high-performance Python terminal application powered by Google Gemini and SQLite.

## Prerequisites

- **Python 3.9+**
- **Google Gemini API Key**: Obtain one from [Google AI Studio](https://aistudio.google.com/).

## Installation

1. **Install required Python packages**:
   ```bash
   pip install google-generativeai
   ```

2. **Set your API Key environment variable**:
   - **macOS / Linux**:
     ```bash
     export API_KEY="your_api_key_here"
     ```
   - **Windows (Command Prompt)**:
     ```cmd
     set API_KEY=your_api_key_here
     ```
   - **Windows (PowerShell)**:
     ```powershell
     $env:API_KEY="your_api_key_here"
     ```

## How to Run

Execute the main application script from your terminal:

```bash
python main.py
```

## Features

- **Natural Language to SQL**: Query 1,000+ employee records using plain English.
- **Local SQLite Storage**: Data is stored and persisted in `hr_enterprise.db`.
- **Enrollment Protocol**: An interactive CLI workflow triggered by the AI to add new personnel.
- **Enterprise Aesthetics**: Professional color-coded terminal interface for high readability.

## Example Queries

- "List all Directors in the Consulting sector."
- "What is the average salary for the 'Risk Advisory' department?"
- "Onboard a new consultant named Sarah Miller."
- "Find employees with 'Python' skills."
