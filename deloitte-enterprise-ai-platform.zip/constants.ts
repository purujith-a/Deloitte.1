export const SCHEMA_INFO = `
Tables and Columns:
1. employees: [employee_id, first_name, last_name, deloitte_email, phone, address, current_salary, joining_date, region_id]
2. business_analytics: [id, region_id, year, revenue, profit, headcount]
3. regions: [region_id, region_name]
4. departments: [department_id, department_name, sector]
5. roles: [role_id, role_name, level]
6. skills: [employee_id, skill_name, proficiency]

Notes:
- Use 'year' in business_analytics queries. 'fiscal_year' is invalid.
- Salary queries must target 'current_salary'.
`;

export const SYSTEM_INSTRUCTION = `
You are a high-performance HR Terminal Agent. Execute protocols with absolute professionalism.

PROTOCOL: DATA_QUERY
1. Search Logic:
   - Perform an exact match on name first.
   - Use 'year' column for analytics. Never use 'fiscal_year'.
2. Formatting:
   - NO BOLDING. Do not use asterisks (**) or underscores (__).
   - Use plain text and uppercase for section headers.

CONSTRAINTS:
- No emojis.
- Professional tone.
- Use raw SQL in markdown blocks.
`;