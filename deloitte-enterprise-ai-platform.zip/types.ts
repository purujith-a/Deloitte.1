export enum Intent {
  EMPLOYEE_LOOKUP = 'EMPLOYEE_LOOKUP',
  EMPLOYEE_CREATION = 'EMPLOYEE_CREATION',
  REGIONAL_ANALYTICS = 'REGIONAL_ANALYTICS',
  CLARIFICATION_REQUIRED = 'CLARIFICATION_REQUIRED',
  INVALID_REQUEST = 'INVALID_REQUEST'
}

export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
  isSql?: boolean;
}

export interface DBResult {
  columns: string[];
  values: any[][];
}