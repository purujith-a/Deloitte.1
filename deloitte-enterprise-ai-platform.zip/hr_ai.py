
import os
import google.generativeai as genai

class HRAgent:
    def __init__(self):
        api_key = os.environ.get("API_KEY")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-3-flash-preview')
        
        self.system_instruction = """
        You are an Enterprise HR Intelligence Bot (Terminal Version).
        
        STRICT FORMATTING:
        - DO NOT use bolding (no ** or __).
        - Use plain text and UPPERCASE for headers.
        - NO EMOJIS.
        
        DATABASE STRUCTURE (EXACT COLUMNS):
        - employees: [employee_id (PK), first_name, last_name, deloitte_email, current_salary, joining_date, region_id]
        - regions: [region_id (PK), region_name]
        - company_growth: [region_id (FK), year, revenue, profit, headcount]
        - departments: [department_id (PK), department_name, sector]
        - roles: [role_id (PK), role_name, level]
        - skills: [employee_id, skill_name, proficiency]

        STRICT SQL CONSTRAINTS:
        1. Use 'employee_id' as the primary key for personnel. NEVER use 'id'.
        2. Use 'year' for all time-based queries.
        3. Use 'current_salary' for employee pay.
        4. Join 'company_growth' with 'regions' on 'region_id' to filter by 'region_name'.
        5. Output SQL block inside ```sql ... ```.
        
        TONE: Professional, concise, terminal-optimized.
        """

    def get_response(self, prompt, is_summary=False):
        try:
            if is_summary:
                response = self.model.generate_content(
                    f"STRICT: NO BOLDING. Summarize in 1 sentence: {prompt}"
                )
            else:
                response = self.model.generate_content(
                    f"{self.system_instruction}\n\nUSER_REQUEST: {prompt}"
                )
            return response.text
        except Exception as e:
            return f"[AI_ERROR] Internal bridge failure: {str(e)}"
